APPID = '10002458'
SECRET_ID = 'AKIDpfLlXhjLoRSEACPSgmqKbTjrnIiyscvR'
SECRET_KEY = 'IMbbMjxmuo7a9Bs2lYijE6Ys79i8y6qC'
# auth info

BUCKET = {'avatar': 'atest'}
# bucket info
